import 'bootstrap/dist/css/bootstrap.min.css';
import 'aos/dist/aos.css';
import '../css/main.css';
import '../css/header.css';
import '../css/hero.css';
import '../css/about.css';
import '../css/services.css';
import '../css/doctors.css';
import '../css/payment.css';
import '../css/contact.css';
import '../css/footer.css';
import '../css/whatsapp.css';

import AOS from 'aos';
import { initHeader } from './components/header.js';
import { initHero } from './components/hero.js';
import { initAbout } from './components/about.js';
import { initServices } from './components/services.js';
import { initDoctors } from './components/doctors.js';
import { initPayment } from './components/payment.js';
import { initContact } from './components/contact.js';
import { initFooter } from './components/footer.js';
import { initWhatsApp } from './components/whatsapp.js';

document.addEventListener('DOMContentLoaded', function() {
  // Initialize AOS animation library
  AOS.init({
    duration: 800,
    easing: 'ease-in-out',
    once: true,
    mirror: false
  });
  
  // Initialize all sections
  initHeader();
  initHero();
  initAbout();
  initServices();
  initDoctors();
  initPayment();
  initContact();
  initFooter();
  initWhatsApp();
  
  // Handle scroll animations manually for older browsers
  document.addEventListener('scroll', checkScroll);
  
  function checkScroll() {
    const elements = document.querySelectorAll('.fade-up');
    
    elements.forEach(el => {
      const elementTop = el.getBoundingClientRect().top;
      const windowHeight = window.innerHeight;
      
      if (elementTop < windowHeight * 0.75) {
        el.classList.add('active');
      }
    });
  }
  
  // Trigger initial check
  checkScroll();
});