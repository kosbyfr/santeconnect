export function initPayment() {
  const paymentElement = document.getElementById('payment');
  
  if (!paymentElement) return;
  
  paymentElement.innerHTML = `
    <div class="container payment-container">
      <div class="section-title fade-up">
        <h2>Options de Paiement</h2>
        <p class="payment-description">Pour votre commodité, Santé Connect accepte diverses méthodes de paiement mobile, vous permettant de régler vos consultations et services médicaux en toute simplicité.</p>
      </div>
      
      <div class="payment-options">
        <div class="payment-option fade-up">
          <div class="payment-logo">
            <img src="https://www.orange.com/sites/orangecom/files/styles/desktop_1920x1080/public/2020-11/LOGO-OM-HORIZ-ORANGE.png?itok=jrL0ZJuF" alt="Orange Money">
          </div>
          <h4 class="payment-name">Orange Money</h4>
          <p class="payment-info">Service de paiement rapide et sécurisé</p>
        </div>
        
        <div class="payment-option fade-up">
          <div class="payment-logo">
            <img src="https://statics.dmst.moov-africa.bj/img/moov-money-logo-white.svg" alt="Moov Money">
          </div>
          <h4 class="payment-name">Moov Money</h4>
          <p class="payment-info">Transfert d'argent instantané</p>
        </div>
        
        <div class="payment-option fade-up">
          <div class="payment-logo">
            <img src="https://wave.com/assets/logo-dark.svg" alt="Wave">
          </div>
          <h4 class="payment-name">Wave</h4>
          <p class="payment-info">Solution de paiement économique</p>
        </div>
        
        <div class="payment-option fade-up">
          <div class="payment-logo">
            <img src="https://brand.mastercard.com/content/dam/mccom/brandcenter/thumbnails/mastercard_vrt_pos_92px_2x.png" alt="Carte bancaire">
          </div>
          <h4 class="payment-name">Carte bancaire</h4>
          <p class="payment-info">Visa, Mastercard acceptés</p>
        </div>
      </div>
      
      <div class="text-center fade-up mt-xl">
        <a href="#contact" class="btn btn-primary">Prendre rendez-vous</a>
      </div>
    </div>
  `;
}