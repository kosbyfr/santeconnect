export function initContact() {
  const contactElement = document.getElementById('contact');
  
  if (!contactElement) return;
  
  contactElement.innerHTML = `
    <div class="container contact-container">
      <div class="contact-info fade-up">
        <h2 class="contact-title">Contactez-nous</h2>
        <p class="contact-description">Vous avez des questions ou souhaitez prendre rendez-vous? N'hésitez pas à nous contacter ou à remplir le formulaire.</p>
        
        <ul class="contact-details">
          <li>
            <div class="contact-icon">
              <i class="bi bi-geo-alt"></i>
            </div>
            <div class="contact-text">
              <h4>Notre adresse</h4>
              <p>123 Avenue Centrale, Dakar, Sénégal</p>
            </div>
          </li>
          
          <li>
            <div class="contact-icon">
              <i class="bi bi-envelope"></i>
            </div>
            <div class="contact-text">
              <h4>Email</h4>
              <p>info@santeconnect.com</p>
            </div>
          </li>
          
          <li>
            <div class="contact-icon">
              <i class="bi bi-phone"></i>
            </div>
            <div class="contact-text">
              <h4>Téléphone</h4>
              <p>+223 76 02 12 04</p>
            </div>
          </li>
          
          <li>
            <div class="contact-icon">
              <i class="bi bi-clock"></i>
            </div>
            <div class="contact-text">
              <h4>Heures d'ouverture</h4>
              <p>Lun-Ven: 8h-18h | Sam: 9h-13h</p>
            </div>
          </li>
        </ul>
      </div>
      
      <div class="contact-form fade-up">
        <form id="appointment-form">
          <div class="form-group">
            <label for="name" class="form-label">Nom complet</label>
            <input type="text" id="name" class="form-control" placeholder="Votre nom" required>
          </div>
          
          <div class="form-group">
            <label for="email" class="form-label">Email</label>
            <input type="email" id="email" class="form-control" placeholder="Votre email" required>
          </div>
          
          <div class="form-group">
            <label for="phone" class="form-label">Téléphone</label>
            <input type="tel" id="phone" class="form-control" placeholder="Votre numéro de téléphone" required>
          </div>
          
          <div class="form-group">
            <label for="service" class="form-label">Service</label>
            <select id="service" class="form-control" required>
              <option value="">Sélectionnez un service</option>
              <option value="consultation">Consultation générale</option>
              <option value="pediatrie">Pédiatrie</option>
              <option value="cardiologie">Cardiologie</option>
              <option value="gynecologie">Gynécologie</option>
              <option value="dermatologie">Dermatologie</option>
              <option value="ophtalmologie">Ophtalmologie</option>
            </select>
          </div>
          
          <div class="form-group">
            <label for="message" class="form-label">Message</label>
            <textarea id="message" class="form-control" placeholder="Votre message ou symptômes"></textarea>
          </div>
          
          <button type="submit" class="btn btn-primary btn-submit">Envoyer la demande</button>
        </form>
      </div>
    </div>
  `;
  
  // Form submission handler
  const form = document.getElementById('appointment-form');
  if (form) {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      // In a real app, you would send this data to your backend
      
      alert('Votre demande a été envoyée! Nous vous contacterons bientôt.');
      form.reset();
    });
  }
}