export function initAbout() {
  const aboutElement = document.getElementById('about');
  
  if (!aboutElement) return;
  
  aboutElement.innerHTML = `
    <div class="container about-container">
      <div class="about-image fade-up">
        <img src="https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="À propos de Santé Connect">
      </div>
      <div class="about-content fade-up">
        <span class="about-subtitle">À propos de nous</span>
        <h2 class="about-title">Centre médical d'excellence depuis 2020</h2>
        <p class="about-text">Santé Connect est un centre médical de premier plan, offrant des soins de santé complets et personnalisés pour toutes les générations. Notre mission est de fournir des services médicaux de haute qualité dans un environnement accueillant et professionnel.</p>
        <p class="about-text">Nous nous engageons à améliorer la santé et le bien-être de nos patients grâce à notre équipe de médecins spécialistes et à nos installations médicales modernes.</p>
        
        <div class="about-features">
          <div class="feature-item fade-up">
            <div class="feature-icon">
              <i class="bi bi-heart-pulse"></i>
            </div>
            <div class="feature-text">
              <h4>Soins personnalisés</h4>
              <p>Traitement adapté à vos besoins spécifiques</p>
            </div>
          </div>
          
          <div class="feature-item fade-up">
            <div class="feature-icon">
              <i class="bi bi-calendar-check"></i>
            </div>
            <div class="feature-text">
              <h4>Rendez-vous flexibles</h4>
              <p>Horaires adaptés à votre emploi du temps</p>
            </div>
          </div>
          
          <div class="feature-item fade-up">
            <div class="feature-icon">
              <i class="bi bi-shield-check"></i>
            </div>
            <div class="feature-text">
              <h4>Médecins qualifiés</h4>
              <p>Équipe médicale expérimentée et certifiée</p>
            </div>
          </div>
          
          <div class="feature-item fade-up">
            <div class="feature-icon">
              <i class="bi bi-cash-coin"></i>
            </div>
            <div class="feature-text">
              <h4>Prix abordables</h4>
              <p>Soins de qualité à des tarifs accessibles</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}