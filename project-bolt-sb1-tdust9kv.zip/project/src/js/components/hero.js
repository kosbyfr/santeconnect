export function initHero() {
  const heroElement = document.getElementById('hero');
  
  if (!heroElement) return;
  
  heroElement.innerHTML = `
    <div class="container">
      <div class="hero-content fade-up">
        <h1 class="hero-title">Votre santé, notre priorité</h1>
        <p class="hero-subtitle">Nous offrons des soins médicaux de qualité avec des médecins spécialistes pour toute la famille. Consultez nos experts et prenez rendez-vous dès aujourd'hui.</p>
        <div class="hero-buttons">
          <a href="#contact" class="btn btn-primary hero-cta">Prendre rendez-vous</a>
          <a href="#services" class="btn btn-outline hero-cta">Nos services</a>
        </div>
      </div>
    </div>
    <div class="wave-bottom">
      <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
        <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" class="shape-fill"></path>
      </svg>
    </div>
  `;
}