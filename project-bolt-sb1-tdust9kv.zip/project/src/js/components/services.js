export function initServices() {
  const servicesElement = document.getElementById('services');
  
  if (!servicesElement) return;
  
  servicesElement.innerHTML = `
    <div class="container services-container">
      <div class="section-title fade-up">
        <h2>Nos Services</h2>
        <p>Découvrez notre gamme complète de services médicaux conçus pour répondre à tous vos besoins de santé.</p>
      </div>
      
      <div class="services-grid">
        <div class="service-card fade-up">
          <div class="service-image">
            <img src="https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Consultation générale">
          </div>
          <div class="service-content">
            <div class="service-icon">
              <i class="bi bi-clipboard2-pulse"></i>
            </div>
            <h3 class="service-title">Consultation générale</h3>
            <p class="service-description">Consultations complètes avec nos médecins généralistes pour tous les problèmes de santé courants.</p>
            <a href="#contact" class="service-link">En savoir plus <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
        
        <div class="service-card fade-up">
          <div class="service-image">
            <img src="https://images.pexels.com/photos/5327656/pexels-photo-5327656.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Pédiatrie">
          </div>
          <div class="service-content">
            <div class="service-icon">
              <i class="bi bi-balloon-heart"></i>
            </div>
            <h3 class="service-title">Pédiatrie</h3>
            <p class="service-description">Soins spécialisés pour les enfants de tous âges, du nouveau-né à l'adolescent.</p>
            <a href="#contact" class="service-link">En savoir plus <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
        
        <div class="service-card fade-up">
          <div class="service-image">
            <img src="https://images.pexels.com/photos/3376790/pexels-photo-3376790.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Cardiologie">
          </div>
          <div class="service-content">
            <div class="service-icon">
              <i class="bi bi-heart"></i>
            </div>
            <h3 class="service-title">Cardiologie</h3>
            <p class="service-description">Diagnostic et traitement des maladies cardiaques par nos spécialistes expérimentés.</p>
            <a href="#contact" class="service-link">En savoir plus <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
        
        <div class="service-card fade-up">
          <div class="service-image">
            <img src="https://images.pexels.com/photos/3985163/pexels-photo-3985163.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Gynécologie">
          </div>
          <div class="service-content">
            <div class="service-icon">
              <i class="bi bi-gender-female"></i>
            </div>
            <h3 class="service-title">Gynécologie</h3>
            <p class="service-description">Soins spécialisés pour la santé reproductive et le bien-être des femmes.</p>
            <a href="#contact" class="service-link">En savoir plus <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
        
        <div class="service-card fade-up">
          <div class="service-image">
            <img src="https://images.pexels.com/photos/3779698/pexels-photo-3779698.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Dermatologie">
          </div>
          <div class="service-content">
            <div class="service-icon">
              <i class="bi bi-bandaid"></i>
            </div>
            <h3 class="service-title">Dermatologie</h3>
            <p class="service-description">Traitement des affections cutanées et soins de la peau par nos dermatologues.</p>
            <a href="#contact" class="service-link">En savoir plus <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
        
        <div class="service-card fade-up">
          <div class="service-image">
            <img src="https://images.pexels.com/photos/3845810/pexels-photo-3845810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Ophtalmologie">
          </div>
          <div class="service-content">
            <div class="service-icon">
              <i class="bi bi-eye"></i>
            </div>
            <h3 class="service-title">Ophtalmologie</h3>
            <p class="service-description">Examens de la vue complets et traitement des affections oculaires.</p>
            <a href="#contact" class="service-link">En savoir plus <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
      </div>
    </div>
  `;
}