export function initFooter() {
  const footerElement = document.getElementById('site-footer');
  
  if (!footerElement) return;
  
  footerElement.innerHTML = `
    <div class="container footer-container">
      <div class="footer-col footer-about">
        <h3>Santé Connect</h3>
        <p>Centre médical offrant des soins de qualité et des services de santé personnalisés pour toute la famille.</p>
        <div class="footer-social">
          <a href="#"><i class="bi bi-facebook"></i></a>
          <a href="#"><i class="bi bi-twitter"></i></a>
          <a href="#"><i class="bi bi-instagram"></i></a>
          <a href="#"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>
      
      <div class="footer-col footer-links">
        <h3>Liens rapides</h3>
        <ul>
          <li><a href="#hero"><i class="bi bi-chevron-right"></i> Accueil</a></li>
          <li><a href="#about"><i class="bi bi-chevron-right"></i> À propos</a></li>
          <li><a href="#services"><i class="bi bi-chevron-right"></i> Services</a></li>
          <li><a href="#doctors"><i class="bi bi-chevron-right"></i> Médecins</a></li>
          <li><a href="#payment"><i class="bi bi-chevron-right"></i> Paiement</a></li>
          <li><a href="#contact"><i class="bi bi-chevron-right"></i> Contact</a></li>
        </ul>
      </div>
      
      <div class="footer-col footer-contact">
        <h3>Contactez-nous</h3>
        <ul>
          <li><i class="bi bi-geo-alt"></i> 123 Avenue Centrale, Dakar, Sénégal</li>
          <li><i class="bi bi-phone"></i> +223 76 02 12 04</li>
          <li><i class="bi bi-envelope"></i> info@santeconnect.com</li>
          <li><i class="bi bi-clock"></i> Lun-Ven: 8h-18h | Sam: 9h-13h</li>
        </ul>
      </div>
      
      <div class="footer-col footer-newsletter">
        <h3>Newsletter</h3>
        <p>Abonnez-vous à notre newsletter pour recevoir des conseils de santé et les dernières nouvelles.</p>
        <form class="newsletter-form">
          <input type="email" placeholder="Votre email" required>
          <button type="submit">OK</button>
        </form>
      </div>
    </div>
    
    <div class="footer-bottom">
      <div class="container">
        <p>&copy; 2025 Santé Connect. Tous droits réservés.</p>
      </div>
    </div>
  `;
  
  // Newsletter form submission
  const newsletterForm = document.querySelector('.newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function(e) {
      e.preventDefault();
      alert('Merci de vous être abonné à notre newsletter!');
      newsletterForm.reset();
    });
  }
}