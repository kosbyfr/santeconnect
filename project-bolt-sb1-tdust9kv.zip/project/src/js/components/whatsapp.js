export function initWhatsApp() {
  const whatsappElement = document.getElementById('whatsapp-button');
  
  if (!whatsappElement) return;
  
  // WhatsApp number
  const whatsappNumber = "+22376021204";
  const whatsappMessage = "Bonjour, je souhaite prendre un rendez-vous chez Santé Connect.";
  
  // Encode the message for URL
  const encodedMessage = encodeURIComponent(whatsappMessage);
  
  // Create WhatsApp URL
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;
  
  whatsappElement.innerHTML = `
    <a href="${whatsappUrl}" class="whatsapp-btn" target="_blank">
      <i class="bi bi-whatsapp whatsapp-icon"></i>
      <span class="whatsapp-text">Prendre rendez-vous</span>
    </a>
  `;
}