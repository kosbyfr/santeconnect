export function initDoctors() {
  const doctorsElement = document.getElementById('doctors');
  
  if (!doctorsElement) return;
  
  doctorsElement.innerHTML = `
    <div class="container doctors-container">
      <div class="section-title fade-up">
        <h2>Nos Médecins</h2>
        <p>Rencontrez notre équipe de médecins qualifiés dévoués à votre santé et votre bien-être.</p>
      </div>
      
      <div class="doctors-grid">
        <div class="doctor-card fade-up">
          <div class="doctor-image">
            <img src="https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Dr. Marie Diallo">
          </div>
          <div class="doctor-info">
            <h3 class="doctor-name">Dr. Marie Diallo</h3>
            <p class="doctor-specialty">Médecin Généraliste</p>
            <p class="doctor-bio">Plus de 15 ans d'expérience en médecine générale, spécialisée dans les soins préventifs.</p>
            <div class="doctor-social">
              <a href="#" class="social-link"><i class="bi bi-facebook"></i></a>
              <a href="#" class="social-link"><i class="bi bi-twitter"></i></a>
              <a href="#" class="social-link"><i class="bi bi-linkedin"></i></a>
            </div>
          </div>
        </div>
        
        <div class="doctor-card fade-up">
          <div class="doctor-image">
            <img src="https://images.pexels.com/photos/5214959/pexels-photo-5214959.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Dr. Amadou Sow">
          </div>
          <div class="doctor-info">
            <h3 class="doctor-name">Dr. Amadou Sow</h3>
            <p class="doctor-specialty">Cardiologue</p>
            <p class="doctor-bio">Cardiologue certifié avec une expertise dans le diagnostic et le traitement des maladies cardiaques.</p>
            <div class="doctor-social">
              <a href="#" class="social-link"><i class="bi bi-facebook"></i></a>
              <a href="#" class="social-link"><i class="bi bi-twitter"></i></a>
              <a href="#" class="social-link"><i class="bi bi-linkedin"></i></a>
            </div>
          </div>
        </div>
        
        <div class="doctor-card fade-up">
          <div class="doctor-image">
            <img src="https://images.pexels.com/photos/5407206/pexels-photo-5407206.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Dr. Fatou Ndiaye">
          </div>
          <div class="doctor-info">
            <h3 class="doctor-name">Dr. Fatou Ndiaye</h3>
            <p class="doctor-specialty">Pédiatre</p>
            <p class="doctor-bio">Spécialiste en soins pédiatriques avec une approche douce et attentionnée pour les enfants.</p>
            <div class="doctor-social">
              <a href="#" class="social-link"><i class="bi bi-facebook"></i></a>
              <a href="#" class="social-link"><i class="bi bi-twitter"></i></a>
              <a href="#" class="social-link"><i class="bi bi-linkedin"></i></a>
            </div>
          </div>
        </div>
        
        <div class="doctor-card fade-up">
          <div class="doctor-image">
            <img src="https://images.pexels.com/photos/4173251/pexels-photo-4173251.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" alt="Dr. Omar Keita">
          </div>
          <div class="doctor-info">
            <h3 class="doctor-name">Dr. Omar Keita</h3>
            <p class="doctor-specialty">Dermatologue</p>
            <p class="doctor-bio">Expert en soins de la peau avec une spécialisation dans le traitement des affections cutanées complexes.</p>
            <div class="doctor-social">
              <a href="#" class="social-link"><i class="bi bi-facebook"></i></a>
              <a href="#" class="social-link"><i class="bi bi-twitter"></i></a>
              <a href="#" class="social-link"><i class="bi bi-linkedin"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}