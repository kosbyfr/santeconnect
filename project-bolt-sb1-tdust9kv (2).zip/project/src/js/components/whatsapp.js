export function initWhatsApp() {
  const whatsappElement = document.getElementById('whatsapp-button');
  
  if (!whatsappElement) return;
  
  // WhatsApp number and group link
  const whatsappNumber = "+22376021204";
  const whatsappMessage = "Bonjour, je souhaite prendre un rendez-vous chez Santé Connect.";
  const whatsappGroupLink = "https://chat.whatsapp.com/Fj85ZQDXaWR8Wsmz1a5EdB";
  
  // Encode the message for URL
  const encodedMessage = encodeURIComponent(whatsappMessage);
  
  // Create WhatsApp URL
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;
  
  whatsappElement.innerHTML = `
    <div class="whatsapp-buttons">
      <a href="${whatsappUrl}" class="whatsapp-btn" target="_blank">
        <i class="bi bi-whatsapp whatsapp-icon"></i>
        <span class="whatsapp-text">Prendre rendez-vous</span>
      </a>
      <a href="${whatsappGroupLink}" class="whatsapp-btn whatsapp-group" target="_blank">
        <i class="bi bi-people whatsapp-icon"></i>
        <span class="whatsapp-text">Rejoindre le groupe</span>
      </a>
    </div>
  `;
}