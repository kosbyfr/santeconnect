export function initPatientSpace() {
  const patientSpaceElement = document.getElementById('patient-space');
  
  if (!patientSpaceElement) return;
  
  patientSpaceElement.innerHTML = `
    <div class="container patient-space-container">
      <div class="section-title fade-up">
        <h2>Espace Patient</h2>
        <p>Accédez à vos informations médicales et gérez vos rendez-vous en toute sécurité</p>
      </div>
      
      <div class="patient-features">
        <div class="feature-card fade-up">
          <div class="feature-icon">
            <i class="bi bi-journal-medical"></i>
          </div>
          <h3>Dossier Médical</h3>
          <p>Consultez votre historique médical, vos résultats d'analyses et vos ordonnances.</p>
          <a href="#" class="btn btn-primary">Accéder</a>
        </div>
        
        <div class="feature-card fade-up">
          <div class="feature-icon">
            <i class="bi bi-calendar-check"></i>
          </div>
          <h3>Rendez-vous</h3>
          <p>Gérez vos rendez-vous médicaux et recevez des rappels automatiques.</p>
          <a href="#" class="btn btn-primary">Gérer</a>
        </div>
        
        <div class="feature-card fade-up">
          <div class="feature-icon">
            <i class="bi bi-chat-dots"></i>
          </div>
          <h3>Messagerie</h3>
          <p>Communiquez de manière sécurisée avec votre équipe médicale.</p>
          <a href="#" class="btn btn-primary">Messages</a>
        </div>
      </div>
      
      <div class="patient-login fade-up">
        <h3>Connexion Espace Patient</h3>
        <form id="login-form" class="login-form">
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" required>
          </div>
          <div class="form-group">
            <label for="password">Mot de passe</label>
            <input type="password" id="password" required>
          </div>
          <button type="submit" class="btn btn-primary">Se connecter</button>
          <div class="form-links">
            <a href="#">Mot de passe oublié?</a>
            <a href="#">Créer un compte</a>
          </div>
        </form>
      </div>
    </div>
  `;
  
  // Handle login form
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      // Add login logic here
      alert('Fonctionnalité en développement');
    });
  }
}