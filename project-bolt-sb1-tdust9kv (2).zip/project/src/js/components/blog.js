export function initBlog() {
  const blogElement = document.getElementById('blog');
  
  if (!blogElement) return;
  
  blogElement.innerHTML = `
    <div class="container blog-container">
      <div class="section-title fade-up">
        <h2>Actualités</h2>
        <p>Restez informé des dernières nouvelles et avancées dans le domaine de la santé</p>
      </div>
      
      <div class="blog-grid">
        <div class="blog-card fade-up">
          <div class="blog-image">
            <img src="https://images.pexels.com/photos/4226219/pexels-photo-4226219.jpeg" alt="Nouvelles thérapies">
            <div class="blog-category">Recherche</div>
          </div>
          <div class="blog-content">
            <h3>Nouvelles thérapies pour le diabète de type 2</h3>
            <p>Découvrez les dernières avancées dans le traitement du diabète de type 2...</p>
            <div class="blog-meta">
              <span><i class="bi bi-calendar"></i> 15 Jan 2025</span>
              <span><i class="bi bi-person"></i> Dr. Keita</span>
            </div>
            <a href="#" class="blog-link">Lire l'article <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
        
        <div class="blog-card fade-up">
          <div class="blog-image">
            <img src="https://images.pexels.com/photos/4226263/pexels-photo-4226263.jpeg" alt="Alimentation">
            <div class="blog-category">Nutrition</div>
          </div>
          <div class="blog-content">
            <h3>Alimentation équilibrée pour diabétiques</h3>
            <p>Guide pratique pour une alimentation saine adaptée aux diabétiques...</p>
            <div class="blog-meta">
              <span><i class="bi bi-calendar"></i> 12 Jan 2025</span>
              <span><i class="bi bi-person"></i> Dr. Diallo</span>
            </div>
            <a href="#" class="blog-link">Lire l'article <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
        
        <div class="blog-card fade-up">
          <div class="blog-image">
            <img src="https://images.pexels.com/photos/4226270/pexels-photo-4226270.jpeg" alt="Innovation">
            <div class="blog-category">Innovation</div>
          </div>
          <div class="blog-content">
            <h3>Nouveaux dispositifs de surveillance glycémique</h3>
            <p>Les dernières technologies pour un meilleur suivi du diabète...</p>
            <div class="blog-meta">
              <span><i class="bi bi-calendar"></i> 10 Jan 2025</span>
              <span><i class="bi bi-person"></i> Dr. Touré</span>
            </div>
            <a href="#" class="blog-link">Lire l'article <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
      </div>
      
      <div class="text-center fade-up mt-xl">
        <a href="#" class="btn btn-outline">Voir tous les articles</a>
      </div>
    </div>
  `;
}