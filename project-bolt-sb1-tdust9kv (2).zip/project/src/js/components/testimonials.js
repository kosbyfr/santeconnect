export function initTestimonials() {
  const testimonialsElement = document.getElementById('testimonials');
  
  if (!testimonialsElement) return;
  
  testimonialsElement.innerHTML = `
    <div class="container testimonials-container">
      <div class="section-title fade-up">
        <h2>Témoignages</h2>
        <p>Ce que nos patients disent de nos services</p>
      </div>
      
      <div class="testimonials-slider fade-up">
        <div class="testimonial-item active">
          <div class="testimonial-content">
            <p>"Grâce à Santé Connect, j'ai pu avoir accès à des spécialistes du diabète qui m'ont aidé à mieux gérer ma maladie. Le suivi est excellent et les conseils sont précieux."</p>
            <div class="testimonial-author">
              <img src="https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg" alt="Amadou Traoré">
              <div>
                <h4>Amadou Traoré</h4>
                <p>Patient depuis 2022</p>
              </div>
            </div>
          </div>
        </div>
        
        <div class="testimonial-item">
          <div class="testimonial-content">
            <p>"Le service de téléconsultation est vraiment pratique. Je peux consulter mon médecin régulièrement sans avoir à me déplacer. L'équipe est très professionnelle."</p>
            <div class="testimonial-author">
              <img src="https://images.pexels.com/photos/1181695/pexels-photo-1181695.jpeg" alt="Fatoumata Diallo">
              <div>
                <h4>Fatoumata Diallo</h4>
                <p>Patiente depuis 2023</p>
              </div>
            </div>
          </div>
        </div>
        
        <div class="testimonial-item">
          <div class="testimonial-content">
            <p>"L'accompagnement pour mon évacuation sanitaire a été parfait. Tout a été bien organisé et je me suis senti en sécurité tout au long du processus."</p>
            <div class="testimonial-author">
              <img src="https://images.pexels.com/photos/1181688/pexels-photo-1181688.jpeg" alt="Moussa Coulibaly">
              <div>
                <h4>Moussa Coulibaly</h4>
                <p>Patient depuis 2021</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="testimonial-controls fade-up">
        <button class="testimonial-prev"><i class="bi bi-arrow-left"></i></button>
        <button class="testimonial-next"><i class="bi bi-arrow-right"></i></button>
      </div>
    </div>
  `;
  
  // Initialize testimonial slider
  const items = document.querySelectorAll('.testimonial-item');
  const prevBtn = document.querySelector('.testimonial-prev');
  const nextBtn = document.querySelector('.testimonial-next');
  let currentIndex = 0;
  
  function showTestimonial(index) {
    items.forEach(item => item.classList.remove('active'));
    items[index].classList.add('active');
  }
  
  if (prevBtn && nextBtn) {
    prevBtn.addEventListener('click', () => {
      currentIndex = (currentIndex - 1 + items.length) % items.length;
      showTestimonial(currentIndex);
    });
    
    nextBtn.addEventListener('click', () => {
      currentIndex = (currentIndex + 1) % items.length;
      showTestimonial(currentIndex);
    });
  }
  
  // Auto-advance testimonials
  setInterval(() => {
    currentIndex = (currentIndex + 1) % items.length;
    showTestimonial(currentIndex);
  }, 5000);
}