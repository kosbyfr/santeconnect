export function initHealthTips() {
  const healthTipsElement = document.getElementById('health-tips');
  
  if (!healthTipsElement) return;
  
  healthTipsElement.innerHTML = `
    <div class="container health-tips-container">
      <div class="section-title fade-up">
        <h2>Conseils Santé</h2>
        <p>Des conseils pratiques pour prendre soin de votre santé au quotidien</p>
      </div>
      
      <div class="tips-grid">
        <div class="tip-card fade-up">
          <div class="tip-icon">
            <i class="bi bi-heart-pulse"></i>
          </div>
          <h3>Gestion du Diabète</h3>
          <p>Conseils pratiques pour maintenir un taux de glycémie stable et adopter un mode de vie sain.</p>
          <a href="#" class="tip-link">Lire plus <i class="bi bi-arrow-right"></i></a>
        </div>
        
        <div class="tip-card fade-up">
          <div class="tip-icon">
            <i class="bi bi-apple"></i>
          </div>
          <h3>Alimentation Équilibrée</h3>
          <p>Recommandations nutritionnelles adaptées aux personnes diabétiques.</p>
          <a href="#" class="tip-link">Lire plus <i class="bi bi-arrow-right"></i></a>
        </div>
        
        <div class="tip-card fade-up">
          <div class="tip-icon">
            <i class="bi bi-activity"></i>
          </div>
          <h3>Activité Physique</h3>
          <p>Exercices recommandés pour maintenir une bonne santé avec le diabète.</p>
          <a href="#" class="tip-link">Lire plus <i class="bi bi-arrow-right"></i></a>
        </div>
        
        <div class="tip-card fade-up">
          <div class="tip-icon">
            <i class="bi bi-clipboard2-pulse"></i>
          </div>
          <h3>Suivi Médical</h3>
          <p>Importance des contrôles réguliers et du suivi avec votre médecin.</p>
          <a href="#" class="tip-link">Lire plus <i class="bi bi-arrow-right"></i></a>
        </div>
      </div>
    </div>
  `;
}