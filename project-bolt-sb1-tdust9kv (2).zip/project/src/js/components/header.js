export function initHeader() {
  const headerElement = document.getElementById('site-header');
  
  if (!headerElement) return;
  
  headerElement.innerHTML = `
    <div class="container header-container">
      <div class="logo">
        <h1>Santé<span style="color: var(--accent);">Connect</span></h1>
      </div>
      <nav>
        <button class="mobile-toggle" id="mobile-toggle">
          <i class="bi bi-list"></i>
        </button>
        <ul class="nav-menu" id="nav-menu">
          <li><a href="#hero" class="active">Accueil</a></li>
          <li><a href="#about">À propos</a></li>
          <li><a href="#health-tips">Conseil santé</a></li>
          <li><a href="#connection">Mise en relation</a></li>
          <li><a href="#services">Aide et services</a></li>
          <li><a href="#testimonials">Témoignages</a></li>
          <li><a href="#blog">Actualités</a></li>
          <li><a href="#contact">Contact</a></li>
          <li><a href="#patient-space">Espace patient</a></li>
        </ul>
      </nav>
    </div>
  `;
  
  const mobileToggle = document.getElementById('mobile-toggle');
  const navMenu = document.getElementById('nav-menu');
  const navLinks = document.querySelectorAll('.nav-menu a');
  
  if (mobileToggle && navMenu) {
    mobileToggle.addEventListener('click', () => {
      navMenu.classList.toggle('active');
    });
  }
  
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
      
      if (navMenu.classList.contains('active')) {
        navMenu.classList.remove('active');
      }
    });
  });
  
  window.addEventListener('scroll', () => {
    if (window.scrollY > 100) {
      headerElement.classList.add('scrolled');
    } else {
      headerElement.classList.remove('scrolled');
    }
  });
  
  if (window.scrollY > 100) {
    headerElement.classList.add('scrolled');
  }
}