export function initConnection() {
  const connectionElement = document.getElementById('connection');
  
  if (!connectionElement) return;
  
  connectionElement.innerHTML = `
    <div class="container connection-container">
      <div class="section-title fade-up">
        <h2>Mise en Relation</h2>
        <p>Connectez-vous avec les meilleurs spécialistes du diabète au Mali et à l'international</p>
      </div>
      
      <div class="connection-grid">
        <div class="connection-card fade-up">
          <img src="https://images.pexels.com/photos/4225880/pexels-photo-4225880.jpeg" alt="Consultation à distance">
          <div class="connection-content">
            <h3>Consultation à Distance</h3>
            <p>Consultez nos spécialistes depuis le confort de votre domicile via téléconsultation.</p>
            <a href="#contact" class="btn btn-primary">Prendre rendez-vous</a>
          </div>
        </div>
        
        <div class="connection-card fade-up">
          <img src="https://images.pexels.com/photos/4226122/pexels-photo-4226122.jpeg" alt="Réseau international">
          <div class="connection-content">
            <h3>Réseau International</h3>
            <p>Accédez à notre réseau de spécialistes internationaux pour des avis experts.</p>
            <a href="#contact" class="btn btn-primary">En savoir plus</a>
          </div>
        </div>
        
        <div class="connection-card fade-up">
          <img src="https://images.pexels.com/photos/4226256/pexels-photo-4226256.jpeg" alt="Suivi personnalisé">
          <div class="connection-content">
            <h3>Suivi Personnalisé</h3>
            <p>Bénéficiez d'un suivi adapté à vos besoins avec nos médecins spécialistes.</p>
            <a href="#contact" class="btn btn-primary">Commencer le suivi</a>
          </div>
        </div>
      </div>
    </div>
  `;
}