<?php get_header(); ?>

<section id="hero"></section>
<section id="about"></section>
<section id="services"></section>
<section id="doctors"></section>
<section id="payment"></section>
<section id="contact"></section>

<?php get_footer(); ?>