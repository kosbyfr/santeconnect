<?php
if (!defined('ABSPATH')) exit;

// Theme Setup
function sante_connect_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('custom-logo');
    
    // Register menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'sante-connect'),
        'footer' => __('Footer Menu', 'sante-connect')
    ));
}
add_action('after_setup_theme', 'sante_connect_setup');

// Enqueue scripts and styles
function sante_connect_scripts() {
    // Styles
    wp_enqueue_style('bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css');
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700&family=Open+Sans:wght@400;500;600&display=swap');
    wp_enqueue_style('aos-css', 'https://unpkg.com/aos@2.3.1/dist/aos.css');
    wp_enqueue_style('sante-connect-style', get_stylesheet_uri());
    
    // Scripts
    wp_enqueue_script('aos-js', 'https://unpkg.com/aos@2.3.1/dist/aos.js', array(), null, true);
    wp_enqueue_script('sante-connect-main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), null, true);
    
    // Localize script
    wp_localize_script('sante-connect-main', 'santeConnectData', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'whatsappNumber' => '+22376021204'
    ));
}
add_action('wp_enqueue_scripts', 'sante_connect_scripts');

// Custom Post Types
function sante_connect_register_post_types() {
    // Doctors CPT
    register_post_type('doctor', array(
        'labels' => array(
            'name' => __('Doctors', 'sante-connect'),
            'singular_name' => __('Doctor', 'sante-connect')
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-businessman'
    ));
    
    // Services CPT
    register_post_type('service', array(
        'labels' => array(
            'name' => __('Services', 'sante-connect'),
            'singular_name' => __('Service', 'sante-connect')
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-heart'
    ));
}
add_action('init', 'sante_connect_register_post_types');

// Contact Form Handler
function sante_connect_handle_contact_form() {
    if (!isset($_POST['action']) || $_POST['action'] !== 'contact_form') {
        wp_send_json_error('Invalid request');
    }
    
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $service = sanitize_text_field($_POST['service']);
    $message = sanitize_textarea_field($_POST['message']);
    
    $to = get_option('admin_email');
    $subject = 'New Contact Form Submission';
    $body = "Name: $name\n";
    $body .= "Email: $email\n";
    $body .= "Phone: $phone\n";
    $body .= "Service: $service\n";
    $body .= "Message: $message\n";
    
    $headers = array('Content-Type: text/html; charset=UTF-8');
    
    if (wp_mail($to, $subject, $body, $headers)) {
        wp_send_json_success('Message sent successfully');
    } else {
        wp_send_json_error('Failed to send message');
    }
}
add_action('wp_ajax_contact_form', 'sante_connect_handle_contact_form');
add_action('wp_ajax_nopriv_contact_form', 'sante_connect_handle_contact_form');